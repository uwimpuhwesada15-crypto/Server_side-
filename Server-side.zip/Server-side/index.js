const express = require('express');
const app = express();
const port = 3000;

app.get('/users', (req, res) => {
    res.send('This is Get method');
});

app.post('/users', (req, res) => {
    res.send('This is Post method');
});

app.put('/users', (req, res) => {
    res.send('This is Put method');
});

app.delete('/users', (req, res) => {
    res.send('This is Delete method');
}
);

app.patch('/users', (req, res) => {
    res.send('This is Patch method');
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});